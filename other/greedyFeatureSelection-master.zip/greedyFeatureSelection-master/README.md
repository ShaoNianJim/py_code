greedyFeatureSelection
======================

greedy feature selection based on ROC AUC
